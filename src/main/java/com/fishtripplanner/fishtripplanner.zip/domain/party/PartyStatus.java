package com.fishtripplanner.domain.party;

public enum PartyStatus {
    OPEN,
    CLOSED,
    IN_PROGRESS,
    COMPLETED
}