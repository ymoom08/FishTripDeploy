package com.fishtripplanner.domain.party;

enum WaypointType {
    PICKUP, REST, MEAL
}
