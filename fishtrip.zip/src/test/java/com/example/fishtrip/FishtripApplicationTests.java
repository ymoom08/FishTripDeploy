package com.example.fishtrip;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FishtripApplicationTests {

	@Test
	void contextLoads() {
	}

}
