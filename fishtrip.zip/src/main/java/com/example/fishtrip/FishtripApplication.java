package com.example.fishtrip;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FishtripApplication {

	public static void main(String[] args) {
		SpringApplication.run(FishtripApplication.class, args);
	}

}
