package com.fishtripplanner.repository;

import org.springframework.stereotype.Repository;

@Repository
public interface FishTypeRepository {
}
