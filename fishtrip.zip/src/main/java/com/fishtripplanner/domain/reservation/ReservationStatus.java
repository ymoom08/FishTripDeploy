package com.fishtripplanner.domain.reservation;

public enum ReservationStatus {
    REQUESTED, APPROVED, REJECTED, PENDING
}
