package com.fishtripplanner.domain.reservation;

public enum ReservationType {
    BOAT, ROCK, ISLAND, FLOAT, STAY
}
