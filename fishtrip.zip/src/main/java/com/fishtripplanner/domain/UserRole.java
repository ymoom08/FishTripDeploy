package com.fishtripplanner.domain;

public enum UserRole {
    ADMIN, MANAGER, OWNER, PREMIUM, NORMAL
}
